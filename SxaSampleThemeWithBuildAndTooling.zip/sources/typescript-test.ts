function typescriptTest() { 
    console.log("This is the output of the typescriptTest function"); 
}
