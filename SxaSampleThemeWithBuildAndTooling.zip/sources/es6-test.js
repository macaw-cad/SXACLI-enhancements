function es6Test() { 
    console.log("This is the output of the es6Test function"); 
}
